n = int(input())
nums = list(map(int, input().split()))
print(f"合計: {sum(nums)}")
print(f"平均: {undefined_variable}")  # NameError
