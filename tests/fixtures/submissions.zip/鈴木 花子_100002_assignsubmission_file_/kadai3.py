n = int(input())
nums = list(map(int, input().split()))
print("合計:", sum(nums))        # 出力形式が違う
print("平均:", sum(nums) // n)   # 整数除算のバグ

def average(xs):
    return sum(xs) // len(xs)
