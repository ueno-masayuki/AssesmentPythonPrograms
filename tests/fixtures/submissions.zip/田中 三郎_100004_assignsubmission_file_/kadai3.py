while True:
    pass  # 無限ループ
