# 合計と平均を計算するプログラム
n = int(input())
nums = list(map(int, input().split()))
total = sum(nums)
print(f"合計: {total}")
print(f"平均: {total / n}")

def average(xs):
    return sum(xs) / len(xs)
